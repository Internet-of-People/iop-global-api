# Enpoints
API Endpoint for IOP Apps (Core Client and Mobile Apps)

##Core client version check
/core-wallet/checkversion?version=<version>
Example:
http://iopglobalapi-env.yemthitaza.us-east-1.elasticbeanstalk.com/core-wallet/checkversion?version=1.0.0
